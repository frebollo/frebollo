
import numpy as np
import random
import matplotlib.pyplot as plt
from mpl_toolkits import mplot3d

#PROSPECTIVE PATHWAYS FOR THE FUTURE ENERGY TRANSITION

    #1. electric market study
    #2 types of energy generation:
    #wind offshore: 4176MWh/year
    #PV: 1500 MWh/year
    #total amount hours per year = 8760h
    #demand =100Mwh

#1. VARIABLES
demand_opex_maint = 1 #1 euro/MWh
pv_capex = 800000 #Eur/MW
pv_opex_inst = 12000 #12000 e/MW
pv_opex_maint = 1 #1 euro/MWh
w_capex = 1200000 #Eur/MW
w_opex_inst = 20000 #12000 e/MW
w_opex_maint = 1 #1 euro/MWh

pump_capex = 0.4 #Meur/MW
pump_opex_inst = 10000 #Eur/MW
pump_opex_maint = 1 #Eur/MWh
turbine_capex = 0.6 #Meur/MW
turbine_opex_inst = 10000 #Eur/MW
turbine_opex_maint = 1 #Eur/MWh

storage_time_capacity = 12 # variable between 4 to 20h
storage_capex = 0.011 #MEur/MWh
time_amortiguation = 25 #variable between 20 to 30 years
electricity_grid_cost = 130 #Eur/MWh variable between 60 to 200
electricity_grid_sell = 45 #Eur/MWh variable between 35 to 55
rate_discount = 0.045 #% between 3,5 to 5,5
        
p_eff = 1  #pump_efficiency
t_eff = 1 #turbine efficiency



#2. ARRAYS
demand = np.loadtxt(fname = "demand.txt")  #demand = 100Mwh
pv = np.loadtxt(fname = "pv_data.txt")
w = np.loadtxt(fname = "w_data.txt")


#step 1
for x in range(47): # x in range from 0 to 46, because 1MW of installed pv results to 5.3MWh per day and then (24h * 10MWh demand)/5.3MWh = 45.3 < 46MW of pv installed power to cover 240MWh  )
    for y in range (26): #y in range from 0 to 25, because 1MW of installed w results to 9.8MWh per day and then (24h * 10MWh demand)/9.8MWh = 24.5 < 25MW of w installed power to cover 240MWh  ) )
        balance = demand - ( pv * ([numero * x for numero in pv])) - (w * ([numero * y for numero in w])) 


#step 2
#new array of balance_pump_grid_buy, we convert all negative values into zeros, we only write down the demand not fullfilled
for x in range(47): 
    for y in range (26): 
        consum = demand - ( pv * ([numero * x for numero in pv])) - (w * ([numero * y for numero in w]))
        for i in range(24): #24h = 1day 
            if consum[i] < 0 :
                consum[i]= 0
            turbine = max(consum) # we look the maximum value of each consum in one day
           
#step 3
#new balance of balance_turbine_grid_sell, we convert all positive values into zeros, we only write down the excess of renewable generation
for x in range(47): 
    for y in range (26): 
        excess = ( pv * ([numero * x for numero in pv])) + (w * ([numero * y for numero in w])) -  demand 
        for i in range(24): #24h = 1day    
            if excess[i] < 0 :
                excess[i]= 0                          
            pump = max(excess) # we look the maximum value of each excess in one day 
            storage_energy_capacity = storage_time_capacity * pump


#step 4       
for x in range(47): 
    for y in range (26): 
        balance = demand - ( pv * ([numero * x for numero in pv])) - (w * ([numero * y for numero in w])) 
        consum = demand - ( pv * ([numero * x for numero in pv])) - (w * ([numero * y for numero in w]))
        excess = ( pv * ([numero * x for numero in pv])) + (w * ([numero * y for numero in w])) -  demand 
        for i in range(24): #24h = 1day    
            if excess[i] < 0 :
                excess[i]= 0                          
                turbine = max(consum) # we look the maximum value of each consum in one day
                pump = max(excess)  
                storage_energy_capacity = storage_time_capacity * pump
                s = np.ones(24)
                j = 1
                while j < len(s) :
                    s[0] = storage_energy_capacity - balance[0]
                    s[j] = s[j - 1] - balance [j]
                    j = j + 1
            
#Future improvement:
# while s[j] < 0 :
#    s[j] = 0
#    while s[j] > storage_energy_capacity :
#         s[j] = storage_energy_capacity
                
                
                
                
#step 5. 3D plot

years = 25 #for how many years you want to know the cost of the energy
price = 60 # Eur /MWh
cost = 200 # Eur /MWh

for x in range(47): 
    for y in range (26): 
        balance = demand - ( pv * ([numero * x for numero in pv])) - (w * ([numero * y for numero in w])) 
        consum = demand - ( pv * ([numero * x for numero in pv])) - (w * ([numero * y for numero in w]))
        excess = ( pv * ([numero * x for numero in pv])) + (w * ([numero * y for numero in w])) -  demand
        for i in range(24): #24h = 1day    
            if excess[i] < 0 :
                excess[i]= 0                           
            elif consum[i] < 0 :
                consum[i]= 0
            z = (((x * pv_capex) + (y * w_capex ) )/ (years * 365 * 24 )) + ( (cost * (sum (consum))) - (price * (sum(excess))))/(sum(consum) + sum(excess))

#option 1
s, l = np.mgrid[0 : 46 : 46j, 0 : 26 : 26j]
z = 50 * np.sin(s + l)                     # test data
output = plt.subplot(111, projection = '3d')   # 3d projection
output.plot_surface(s, l, z, rstride = 2, cstride = 1, cmap = plt.cm.Blues_r)
output.set_xlabel('x')                         # axis label
output.set_xlabel('y')
output.set_xlabel('z')
plt.show()

#option 2
ax = plt.axes(projection='3d')
ax.scatter(x, y, z, c=z, cmap='viridis', linewidth=0.5)
plt.show()

#option 3
fig = plt.figure(1)
fig.clear()
ax = fig.gca(projection='3d')
X, Y, Z = axes3d.get_test_data(0.05)
# Plot the 3D surface
ax.plot_surface(X, Y, Z, cmap="viridis")
very_small_number = 1e-6
offset = 100
ax.plot_surface(X, Y, Z*very_small_number-offset, cmap="viridis")
plt.show()