#plot 3D

import numpy as np
import random


import matplotlib.pyplot as plt

from mpl_toolkits import mplot3d


for x in range(47): 
    for y in range (26): 
        balance = demand - ( pv * ([numero * x for numero in pv])) - (w * ([numero * y for numero in w])) 
        consum = demand - ( pv * ([numero * x for numero in pv])) - (w * ([numero * y for numero in w]))
        excess = ( pv * ([numero * x for numero in pv])) + (w * ([numero * y for numero in w])) -  demand
        
        z = (((x * pv_capex) + (y * w_capex ) )/ (years * 365 )) - (price * (sum(excess)) + (cost * (sum (consum))
       
ax = plt.axes(projection='3d')
ax.scatter(x, y, z, c=z, cmap='viridis', linewidth=0.5)
plt.show()