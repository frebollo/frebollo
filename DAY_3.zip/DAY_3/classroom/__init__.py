from .student import Person, Student
from .teacher import Person, Teacher
