#Dangerous Birds

class Birds:
	def __init__(self):
		self.members = ['Owl', 'Eagle','Ostrich']

	def printMembers(self):
		print('Dangerous Birds:')
		for member in self.members:
			print('\t '+ member)
