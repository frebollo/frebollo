#init script
from .fish import Fish
from .birds import Birds
from .mammals import Mammals