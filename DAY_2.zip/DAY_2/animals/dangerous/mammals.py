#Dangerous Mammals

class Mammals:
	def __init__(self):
		self.members = ['Lion','Buffalo','Tiger']

	def printMembers(self):
		print('Dangerous Mammals:')
		for member in self.members:
			print('\t '+ member)
