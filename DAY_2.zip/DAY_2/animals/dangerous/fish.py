#Dangerous Fish

class Fish:
	def __init__(self):
		self.members = ['White Shark','Jellyfish','Eel']

	def printMembers(self):
		print('Dangerous Fish:')
		for member in self.members:
			print('\t '+ member)
