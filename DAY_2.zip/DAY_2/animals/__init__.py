from .harmless.birds import Birds
from .harmless.mammals import Mammals
from .harmless.fish import Fish
from .dangerous.fish import Fish
from .dangerous.mammals import Mammals
from .dangerous.birds import Birds