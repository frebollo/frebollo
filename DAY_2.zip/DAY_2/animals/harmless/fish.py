#Harmless Fish

class Fish:
	def __init__(self):
		self.members = ['Carp','Catfish','Icefish']

	def printMembers(self):
		print('Harmless Fish:')
		for member in self.members:
			print('\t '+ member)
