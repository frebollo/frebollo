#Harmless Birds

class Birds:
	def __init__(self):
		self.members = ['Canaries','Finches','Parakeets']

	def printMembers(self):
		print('Harmless Birds:')
		for member in self.members:
			print('\t '+ member)
