#init script

from .birds import Birds
from .fish import Fish
from .mammals import Mammals