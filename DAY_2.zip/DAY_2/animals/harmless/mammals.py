#Harmless Mammals

class Mammals:
	def __init__(self):
		self.members = ['Dog','Pig','Hamster']

	def printMembers(self):
		print('Harmless Mammals:')
		for member in self.members:
			print('\t '+ member)
