import numpy as np
import random



# Program to multiply two matrices using nested loops

N = 250

# NxN matrix
#We add here @profile
def variable_x(N):
    X = []
    for i in range(N):
        X.append([random.randint(0,100) for r in range(N)])
    return X

# Nx(N+1) matrix
#We add here @profile
def variable_y(N):
    Y = []
    for i in range(N):
        Y.append([random.randint(0,100) for r in range(N+1)])
    return Y

def matmul():
    a = np.array(X)
    b = np.array(Y)
    return(np.matmul(a, b))

X = variable_x(N)
Y = variable_y(N)
res = matmul()

print("Result of multiplying matrices")
for r in res:
	print(res)
