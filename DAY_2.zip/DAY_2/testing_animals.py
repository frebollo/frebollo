#testing exercise 1

import animals

#Mammals
dangerousmammals = animals.dangerous.Mammals()
dangerousmammals.printMembers()
harmlessmammals = animals.harmless.Mammals()
harmlessmammals.printMembers()

#Birds
dangerousbirds = animals.dangerous.Birds()
dangerousbirds.printMembers()
harmlessbirds = animals.harmless.Birds()
harmlessbirds.printMembers()

#Fish
dangerousfish = animals.dangerous.Fish()
dangerousfish.printMembers()
harmlessfish = animals.harmless.Fish()
harmlessfish.printMembers()
