#first of all: import ipdb; ipdb.set_trace()
from dicegame.runner import GameRunner

def main():
    print("Sum all the values of the dice")
    print("You can see it's so easy")
    print("What are you doing with your life?")
    GameRunner.run()


if __name__ == "__main__":
    main()
